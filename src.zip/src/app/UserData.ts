export class UserData
{
        
                id:String;
                firstame:String;
                lastname:String;
                email:String;
                password:String;
                data:Array<any>;
                date:Date;
                v:Number


        
}